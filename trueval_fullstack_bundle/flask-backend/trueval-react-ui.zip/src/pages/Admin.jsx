export default function Admin() {
  return <div className="p-4 text-xl font-semibold">Admin Dashboard</div>;
}

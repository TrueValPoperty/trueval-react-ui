export default function App() {
  return <div className="p-4">Welcome to TrueVal Admin UI</div>;
}


# TrueVal React UI

This is a placeholder for your Vite + React admin panel.
You can migrate your .jsx files into /src and build with:

```bash
npm install
npm run dev
```
